import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: FirebaseOptions(
      apiKey: "AIzaSyAW-G9IeucGEXgZn4uw1GdYEd7ttCRYCXk",
      appId: "1:356134876403:web:8a728217d8bc7824a9b386",
      messagingSenderId: "356134876403",
      projectId: "english-3b09d",
    ),
  );
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Favorite Car',
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() {
    return _MyHomePageState();
  }
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Favorite Car Votes')),
      body: _buildBody(context),
    );
  }

  Widget _buildBody(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('drivers').snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return LinearProgressIndicator();

        return _buildList(context, snapshot.data!.docs);
      },
    );
  }

  Widget _buildList(BuildContext context, List<DocumentSnapshot> snapshot) {
    return ListView(
      padding: const EdgeInsets.only(top: 20.0),
      children: snapshot.map((data) => _buildListItem(context, data)).toList(),
    );
  }

  Widget _buildListItem(BuildContext context, DocumentSnapshot data) {
    final record = Record.fromSnapshot(data);
    return Padding(
        key: ValueKey(record.name),
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey),
            borderRadius: BorderRadius.circular(5.0),
          ),
          child: ListTile(
            title: Row(
              children: [
                Text("Driver Name: "),
                Text(record.name, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.red)),
              ],
            ),
            trailing: Column(
              children: [
                // Text("Age"),
                Text(record.age.toString(), style: TextStyle(fontSize: 18)),
                Text(record.gender.toString()),
              ],
            ),
            /*
              onTap: () 
              => record.reference.update(
                {
                    'age': FieldValue.increment(1)
                  }
                  )
*/

            onTap: () {
              if (record.age > 50) {
                print(record.name + " Is granny");
                record.reference.update({
                  'name': "koko"
                });
              }
            },
          ),
        ));
  }
}

class Record {
  final String name;
  final int age;
  //final String driverName;
  final String gender;
  final int id;
  final DocumentReference reference;

  Record.fromMap(Map<String, dynamic> map, {required this.reference})
      : assert(map['name'] != null),
        assert(map['age'] != null),
        assert(map['gender'] != null),
        assert(map['id'] != null),
        // assert(map['driverName'] != null),
        id = map['id'],
        name = map['name'],
        age = map['age'],
        gender = map['gender'];
  // driverName = map['driverName'];
  Record.fromSnapshot(DocumentSnapshot snapshot) : this.fromMap(snapshot.data() as Map<String, dynamic>, reference: snapshot.reference);
  @override
  String toString() => "Record<$name:$age>";
}
